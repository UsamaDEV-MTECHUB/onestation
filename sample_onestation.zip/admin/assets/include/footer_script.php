<script src="assets/plugins/global/plugins.bundlee45f.js?v=2.0.6"></script>
		<script src="assets/plugins/custom/prismjs/prismjs.bundlee45f.js?v=2.0.6"></script>
		<script src="assets/js/scripts.bundlee45f.js?v=2.0.6"></script>
		<script src="assets/plugins/custom/fullcalendar/fullcalendar.bundlee45f.js?v=2.0.6"></script>
		<script src="http://maps.google.com/maps/api/js?key=AIzaSyBTGnKT7dt597vo9QgeQ7BFhvSRP4eiMSM"></script>
		<script src="assets/plugins/custom/gmaps/gmapse45f.js?v=2.0.6"></script>
		<script src="assets/js/pages/widgetse45f.js?v=2.0.6"></script>
		    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
